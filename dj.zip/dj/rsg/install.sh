#!/bin/bash

ln -s $(pwd)/rsg /usr/local/bin
rsg
