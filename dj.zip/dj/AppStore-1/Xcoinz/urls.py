from django.urls import path
from . import views
from django.urls import reverse_lazy
#from . import views , hhh



urlpatterns = [
    path('', views.index, name='index'),
    path('post/', views.individual_post, name='individual_post')
]
