from django.shortcuts import render
from django.http import HttpResponse
import os , sys

# Create your views here.  Things To do
# after editing here
# open up Xcoinz/urls.py add The changes made here too, to the links patterns there too
# and open up AppStore/urls.py too To specify the makeings made in Xcoinz/urls.py

nn = os.listdir()

def index(request):
    for i in nn:
        return HttpResponse('<h1>Hello, welcome to the index page</h1> ' + i +  "<title>Hello</title>") # returns the index.html template

def individual_post(request):
    return HttpResponse('Hi, this is where an individual post will be.')
