from os import system as os
from time import sleep as ti


kk = 6*6

for i in range (kk):
    print("\n\t\t\t\t", i+1)
