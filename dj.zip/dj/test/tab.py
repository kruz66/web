import sys

from os import system as os
from time import sleep as ti

class l:
    os("clear")
    ti(1)
    print("closing")
    exit(1)
    print("laok")

