import os ,sys

num = os.system("ls *")


for i in range (int(num)):
    print(i)
