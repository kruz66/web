import smtplib
import sys
from os import system as os
from time import sleep as ti

os("clear")

class start:
   n_1 = "=================================================\n"
   n_2 = "GMAIL Cracking SCRIPT\tby\n† : Anonymorzz:Kruz †\nAnonymorzz@gmail.com\n"


for char in '\033[92m' + start.n_1 + "\n" + '\033[3m' + start.n_2: # green red
    sys.stdout.write(char)
    sys.stdout.flush()
    ti(0.02)



# Choose

def lolo():
    print("\n[1] START ©racking")
    print("[2] EXIT ©0DE")
lolo()

nn_1 = '\033[91m' + "Enter::"   # red
for tins in nn_1:
    sys.stdout.write(tins)
    sys.stdout.flush()
    ti(0.1)
choose = int(input(" shshjssjs"))

if choose == 1:
    nn_2 = "\tPATH TO passwords file"
    for tins in nn_2:
        sys.stdout.write(tins)
        sys.stdout.flush()
        ti(0.05)
    file_path = input(":: ")
else:
   os("clear")
   print("EXITING D SCRIPT")
   exit()
pass_file = open(file_path,"r")
pass_list = pass_file.readlines()
for oo in pass_list:
    print("\t\t" , oo)
    ti(0.1)


def login():
    i = 0
    nn_3 = "\tENTER D EMAIL NANE"
    for tins in nn_3:
        sys.stdout.write(tins)
        sys.stdout.flush()
        ti(0.06)
    user_name = input(":: ")
    pass_file = open(file_path,"r")
    pass_list = pass_file.readlines()
    for oo in pass_list:
        print("\t\t" , oo)

# login()
